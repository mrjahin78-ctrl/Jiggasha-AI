# Jiggasha Offline Demo — APK বানানোর নির্দেশনা

এটি একটি অফলাইন Android app demo project, সরাসরি APK নয়। এটি কোনো AI model ব্যবহার করে না; কয়েকটি নমুনা প্রশ্নে পূর্বনির্ধারিত উত্তর দেয়।

## ফোন দিয়েই APK বানানো (ফ্রি GitHub Actions)
1. GitHub-এ সাইন ইন করে **New repository** তৈরি করো, নাম `jiggasha-offline-demo`।
2. ZIP extract করে সব ফাইল repository-তে upload করো; `.github/workflows/build-apk.yml`-সহ hidden `.github` folder-টিও upload করতে হবে। GitHub ওয়েবসাইটে Add file → Upload files ব্যবহার করা যায়।
3. Commit changes করো।
4. Repository-এর **Actions** tab খুলে `Build Jiggasha APK` workflow নির্বাচন করো।
5. **Run workflow** চাপো (push হলে নিজেও চলবে)।
6. সফল হলে workflow run-এর নিচে **Artifacts** থেকে `Jiggasha-Offline-Demo-APK` ডাউনলোড করো। ZIP খুলে `app-debug.apk` ইনস্টল করো।

## সীমাবদ্ধতা
- এটি শুধু UI/নমুনা উত্তর পরীক্ষা করার offline demo; আসল AI নেই।
- APK debug build; Play Store release-এর জন্য signed release build প্রয়োজন।
- APK কেবল নিজের তৈরি project থেকে build করে শেয়ার করো।
